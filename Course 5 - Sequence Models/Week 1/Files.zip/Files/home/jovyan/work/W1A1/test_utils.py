def rnn_cell_forward_test(rnn_cell_forward):
    raise NotImplementedError


def rnn_forward_test(rnn_forward):
    raise NotImplementedError


def lstm_cell_forward_test(lstm_cell_forward):
    raise NotImplementedError


def lstm_forward_test(lstm_forward):
    raise NotImplementedError


def rnn_cell_backward_test(rnn_cell_backward):
    raise NotImplementedError


def rnn_backward_test(rnn_backward):
    raise NotImplementedError


def lstm_cell_backward_test(lstm_cell_backward):
    raise NotImplementedError


def lstm_backward_test(lstm_backward):
    raise NotImplementedError
