def rnn_cell_forward_test(rnn_cell_forward):
    raise NotImplementedError


def clip_test(clip):
    raise NotImplementedError


def sample_test(sample):
    raise NotImplementedError


def optimize_test(optimize):
    raise NotImplementedError


def model_test(model):
    raise NotImplementedError
